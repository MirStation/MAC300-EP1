Para facilitar a execu��o do exerc�cio programa, criamos um makefile com as seguintes op��es de execu��o:

make gs - cria o execut�vel para as fun��es da parte 2 do ep;
make pds - cria o execut�vel para a fun��es da parte 1 do ep;
make all (ou simplesmente make) - cria os execut�veis para a parte 1 e 2 do exerc�cio programa.
